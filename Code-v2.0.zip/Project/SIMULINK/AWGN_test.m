function y = AWGN_test(x, snr)
    % Additive White Gaussian Noise
    % x: Raw Signal (vector)
    % snr: SNR (decibel)
    
    snr = 10^(snr / 10.0);
    xpower = sum(x.^2) / length(x);
    npower = xpower / snr;
    
    if isreal(x(1))
        noise = randn(size(x)) * sqrt(npower);  % Real Number
    else
        noise = (randn(size(x)) + 1i * randn(size(x))) * sqrt(0.5 * npower);  % Complex Number
    end
    
    y = x + noise;
end
