filename_1 = 'lena.jpg'; % JPEG文件的路径
rawData_1 = readJpegRawData(filename_1);
% 现在，rawData包含了文件的原始二进制数据

newFilename_1 = 'lena_new_1.jpg'; % 新JPEG文件的名称
saveJpegRawData(rawData_1, newFilename_1);

tmp=imread('lena.jpg');
imwrite(tmp, 'lena_new_2.jpg', 'jpg', 'Quality', 50);
filename_2 = 'lena_new_2.jpg';
rawData_2 = readJpegRawData(filename_2);

newFilename_2 = 'lena_new_3.jpg'; % 新JPEG文件的名称
saveJpegRawData(rawData_2, newFilename_2);
