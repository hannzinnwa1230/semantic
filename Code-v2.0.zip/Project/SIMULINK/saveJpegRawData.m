function saveJpegRawData(rawData, newFilename)
    fileId = fopen(newFilename, 'wb'); % 打开文件用于写入，'wb'模式表示以二进制形式写入
    if fileId == -1
        error('File cannot be opened for writing: %s', newFilename);
    end
    fwrite(fileId, rawData, 'uint8'); % 将原始数据作为uint8类型写入文件
    fclose(fileId); % 关闭文件
end
