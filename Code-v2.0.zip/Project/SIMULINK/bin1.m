function temp_data_reshape = bin1(test)

test=test*1e7;

% 将矩阵元素转换为二进制序列
binaryMatrix = arrayfun(@(x) dec2bin(x, max(ceil(log2(test(:))))), test, 'UniformOutput', false);

% 将二进制序列拆分为0和1，并存储为矩阵
binarySplitMatrix = cellfun(@(x) reshape(str2num(x')', 1, []), binaryMatrix, 'UniformOutput', false);

% 将cell数组转换为矩阵
binaryResultMatrix = cell2mat(binarySplitMatrix);

temp_data=reshape(binaryResultMatrix,28,64);
temp1_ones=randi([0,1],18,64);
temp2_ones=randi([0,1],18,64);

temp_data_reshape=[temp1_ones;temp_data;temp2_ones];
