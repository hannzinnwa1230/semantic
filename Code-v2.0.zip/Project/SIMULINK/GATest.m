clc;
clear;
close all;

%% 参数设置
originalimage = imread("./TrainPic/Test/lena.tiff");
% peppers.tiff
% lena.tiff
% baboon.tiff
% airplane.tiff
% originalwatermark = imread("uestc.bmp");
% temp_test_1=[[ 8.892086   2.5548177  2.6374872  1.5766894]
%  [11.846643   7.109644   1.5175437  7.1242013]
%  [10.710667   3.2525904  9.297316   4.42019  ]
%  [ 5.325512   4.7994957  1.8940842  6.6524844]
%  [ 5.09738    9.874977  13.429089   2.25565  ]
%  [ 4.573896   3.8574762  1.6581953  4.460027 ]
%  [ 8.59332    6.002548   8.963325   6.4220924]
%  [ 9.972875   5.1412272  8.122083   7.9075556]
%  [ 8.03007    9.211128   5.030007   6.824195 ]
%  [ 7.588398   7.2953386  9.762885   2.0278094]
%  [ 4.1039505  6.2196712  4.452737   5.9302087]
%  [ 5.0736356 11.236098   6.5961647  3.5077233]
%  [ 3.0948272  8.75057    3.7505405  5.84871  ]
%  [ 7.2343664  5.710694   3.7123504  2.1045477]
%  [11.376616   5.841233   7.662611   5.5186615]
%  [ 0.         8.401035   5.7363653  7.9992776]];
% test=bin1(temp_test_1);
temp_test_1=load('C:\Users\FRH\Desktop\Code\data_1.txt');
temp1=reshape(temp_test_1,1,784*4);
temp1_ones=randi([0,1],1,480);
temp2_ones=randi([0,1],1,480);
test=[temp1_ones temp1 temp2_ones];
test=reshape(test,64,64);
test_gray=mat2gray(test,[0 255]);
originalwatermark=gray2rgb(test_gray);
beta = 50;

    %% 定义遗传算法参数
NIND=25;        %个体数目
MAXGEN=100;      %最大遗传代数
PRECI=16;       %变量的二进制位数
GGAP=0.95;      %代沟
px=0.7;         %交叉概率
pm=0.01;        %变异概率
N = 1;          %元素个数
trace=zeros(N+1,MAXGEN);                        %寻优结果的初始值

FieldD=[repmat(PRECI,1,N);repmat([5;10],1,N);repmat([1;0;1;1],1,N)];                      %区域描述器
Chrom=crtbp(NIND,PRECI*N);                      %初始种群
%% 优化
gen=0;                                 %代计数器
X=bs2rv(Chrom,FieldD);                 %计算初始种群的十进制转换
ObjV=fitnessfun(originalimage,originalwatermark,X,beta);       %计算目标函数值
while gen<MAXGEN
   fprintf('%d\n',gen)
   FitnV=ranking(-ObjV);                              %分配适应度值
   SelCh=select('sus',Chrom,FitnV,GGAP);              %选择
   SelCh=recombin('xovsp',SelCh,px);                  %重组
   SelCh=mut(SelCh,pm);                               %变异
   X=bs2rv(SelCh,FieldD);               %子代个体的十进制转换
   ObjVSel=fitnessfun(originalimage,originalwatermark,X,beta);             %计算子代的目标函数值
   [Chrom,ObjV]=reins(Chrom,SelCh,1,1,ObjV,ObjVSel); %重插入子代到父代，得到新种群
   X=bs2rv(Chrom,FieldD);
   gen=gen+1;                                             %代计数器增加
   %获取每代的最优解及其序号，Y为最优解,I为个体的序号
   [Y,I]=max(ObjV);
   trace(1:N,gen)=X(I,:);                       %记下每代的最优值
   trace(end,gen)=Y;                               %记下每代的最优值
end
%% 画进化图
plot(1:MAXGEN,trace(end,:));
grid on
xlabel('遗传代数')
ylabel('性能变化')
title('进化过程')
bestY = trace(end,end);
bestX=trace(1:end-1,end);
fprintf(['最优嵌入因子:\nX=',num2str(bestX'),'\n最优性能err=',num2str(bestY),'\n'])

function output = fitnessfun(originalimage,originalwatermark,alpha,beta)

size_alpha = size(alpha);
for i = 1:size_alpha(1)
    [img_watermark,realwatermark] = AddWatermark(originalimage,originalwatermark,alpha(i,:));
    PSNR = PSNRCalc(originalimage,img_watermark);
    watermark_pick = PickWatermark(img_watermark,alpha(i,:));
    NC = NCCalc(realwatermark,watermark_pick);
    output(i,1) = PSNR+beta*NC;
end

end
