clc;
clear;
close all;

temp_test_1=[[ 8.892086   2.5548177  2.6374872  1.5766894]
 [11.846643   7.109644   1.5175437  7.1242013]
 [10.710667   3.2525904  9.297316   4.42019  ]
 [ 5.325512   4.7994957  1.8940842  6.6524844]
 [ 5.09738    9.874977  13.429089   2.25565  ]
 [ 4.573896   3.8574762  1.6581953  4.460027 ]
 [ 8.59332    6.002548   8.963325   6.4220924]
 [ 9.972875   5.1412272  8.122083   7.9075556]
 [ 8.03007    9.211128   5.030007   6.824195 ]
 [ 7.588398   7.2953386  9.762885   2.0278094]
 [ 4.1039505  6.2196712  4.452737   5.9302087]
 [ 5.0736356 11.236098   6.5961647  3.5077233]
 [ 3.0948272  8.75057    3.7505405  5.84871  ]
 [ 7.2343664  5.710694   3.7123504  2.1045477]
 [11.376616   5.841233   7.662611   5.5186615]
 [ 0.         8.401035   5.7363653  7.9992776]];
test=bin1(temp_test_1);
test_gray=mat2gray(test,[0 255])
originalwatermark=gray2rgb(test_gray);

% originalwatermark = imread("UESTC.bmp");
originalimage = imread("lena.tiff");
alpha = 25;
[img_watermark,realwatermark] = AddWatermark(originalimage,originalwatermark,alpha);
PSNR = PSNRCalc(originalimage,img_watermark)
txData = DataForm(img_watermark);
tximage = img_watermark;
img_rec = DataDisForm(txData,tximage);
img_watermark = img_rec;

% logo = imresize(imread("pic10.jpg"),[64,64]);
% img_logo = img_watermark;
% img_logo(1:64,1:64,:) = logo(1:64,1:64,:);
% imshow(img_logo)

img_logo = img_watermark;

watermark_pick = PickWatermark(img_logo,alpha);
NC = NCCalc(realwatermark,watermark_pick)
