# 定义参数
total_bits = 6380352  # 总比特数
modulation_bits = 4  # 64-QAM 每符号比特数
coding_rate = 1/2  # 编码率

# 计算每个OFDM符号的有效比特数
effective_bits_per_symbol = modulation_bits * coding_rate

# 计算总符号数
total_symbols = total_bits / effective_bits_per_symbol

print(total_symbols)
