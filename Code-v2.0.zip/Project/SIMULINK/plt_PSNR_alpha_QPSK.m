clear all;clc

alpha=8:2:20;
bit=[33.10441526
33.09137136
33.07790742
33.06512337
33.05498195
33.04327083
33.0258708
];
Sematic=[15.34053473
20.10887838
30.16231836
29.4706194
34.96354565
35.5326159
35.5326159
];
figure;
plot(alpha,bit,'-+');
hold on;
plot(alpha,Sematic,'--');
hold on;
xlabel('Alpha');
ylabel('PSNR');
title('QPSK测试');
legend('bit','Sematic');