clear all;clc
img=imread('img_mnist.jpg');

QF=2;

imwrite(img, 'img_mnist_QF.jpg', 'jpg', 'Quality', QF);
output=imread('img_mnist_QF.jpg');

imgInfo=imfinfo('img_mnist.jpg');
imgInfo.FileSize
imgInfo=imfinfo('img_mnist_QF.jpg');
imgInfo.FileSize
figure;
subplot(1,2,1);
imshow(img);
subplot(1,2,2);
imshow(output);