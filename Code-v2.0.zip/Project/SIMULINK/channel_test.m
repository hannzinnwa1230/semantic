% 假设参数设置
numSym = 1e4; % 符号数量
snrRange = 0:2:30; % SNR范围，从0 dB到30 dB，步长为2 dB
ber = zeros(size(snrRange)); % 初始化误码率数组

% 创建一个64QAM调制器和解调器
modulator = comm.RectangularQAMModulator('ModulationOrder', 64, 'NormalizationMethod', 'Average power');
demodulator = comm.RectangularQAMDemodulator('ModulationOrder', 64, 'NormalizationMethod', 'Average power');

% 创建莱斯信道对象
ricianChan = comm.RicianChannel(...
    'SampleRate', 20e6, ... % 采样率20 MHz
    'KFactor', 7, ... % K因子
    'PathDelays', [0 1e-6], ... % 路径延迟
    'AveragePathGains', [0 -10], ... % 平均路径增益
    'MaximumDopplerShift', 5, ... % 最大多普勒频移
    'DopplerSpectrum', doppler('Jakes'), ... % 多普勒频谱
    'RandomStream', 'mt19937ar', ... % 随机数生成器
    'Seed', 1); % 随机数种子

% 创建误码率计算器
berCalc = comm.ErrorRate;

for n = 1:length(snrRange)
    % 重置误码率计算器和莱斯信道状态
    reset(berCalc);
    reset(ricianChan);

    % 生成随机比特
    dataIn = randi([0 63], numSym, 1);

    % 64QAM调制
    modSig = modulator(dataIn);

    % 通过莱斯信道
    fadedSig = ricianChan(modSig);

    % 添加AWGN
    rxSig = awgn(fadedSig, snrRange(n), 'measured');

    % 64QAM解调
    dataOut = demodulator(rxSig);

    % 计算并存储误码率
    berResult = berCalc(dataIn, dataOut);
    ber(n) = berResult(1);
end

% 绘制结果
figure;
plot(snrRange, ber, 'bo-');
xlabel('SNR (dB)');
ylabel('BER');
title('64QAM over Rician Channel BER Performance');
grid on;
