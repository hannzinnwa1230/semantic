function rawData = readJpegRawData(filename)
    fileId = fopen(filename, 'rb'); % 打开文件用于读取，'rb'模式表示以二进制形式读取
    if fileId == -1
        error('File cannot be opened: %s', filename);
    end
    rawData = fread(fileId, inf, '*uint8'); % 读取文件的全部内容为uint8类型的数据
    fclose(fileId); % 关闭文件
end
