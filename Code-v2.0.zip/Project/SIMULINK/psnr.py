import imageio
from skimage.metrics import peak_signal_noise_ratio as psnr
from skimage.metrics import structural_similarity as ssim
import numpy as np

# 读取图像
image_true = imageio.imread(
    'C:\\Users\\FRH\\Desktop\\Code\\2023凌特杯\\Project\\SIMULINK\\com_tx.jpg')
image_test = imageio.imread(
    'C:\\Users\\FRH\\Desktop\\Code\\2023凌特杯\\Project\\SIMULINK\\com_rx.jpg')

# 计算 PSNR
# 假设这两幅图像都是 uint8 类型的，即像素值范围为 0 到 255
# 如果图像是浮点类型并且像素值已经被标准化到 0 到 1 的范围，则不需要指定 data_range 参数
PSNR_value = psnr(image_true, image_test,
                  data_range=image_true.max()-image_test.min())
SSIM_value = ssim(image_true, image_test,
                  data_range=image_true.max()-image_test.min(), multichannel=False)

print(f"PSNR value: {PSNR_value} dB")


def calculate_nc(original, extracted):
    """
    计算并返回原始水印与提取水印之间的标准化相关系数(Normalized Correlation, NC).

    参数:
    original -- 原始水印数据
    extracted -- 提取的水印数据
    """
    # 确保原始和提取的水印被转换为NumPy数组
    original = np.array(original)
    extracted = np.array(extracted)

    # 计算NC值
    numerator = np.sum(original * extracted)
    denominator = np.sqrt(np.sum(original**2) * np.sum(extracted**2))
    nc_value = numerator / denominator

    return nc_value


# nc_value = calculate_nc(image_true, image_test)
# print(f"NC value: {nc_value}")
