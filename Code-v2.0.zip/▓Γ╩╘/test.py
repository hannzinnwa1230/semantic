import torch
import torch.nn as nn


class AdvancedNet(nn.Module):
    def __init__(self):
        super(AdvancedNet, self).__init__()
        self.fc1 = nn.Linear(10, 5)
        self.relu = nn.ReLU()
        self.fc2 = nn.Linear(5, 2)
        # 初始化时不存储任何东西
        self.hidden_layer_input = None

    def forward(self, x, inject_input=None, record_input=False):
        # 如果inject_input不为None，假设我们要将其注入到relu激活后的结果中
        if inject_input is not None:
            x = self.fc2(inject_input)
            return x

        # 正常流程，同时检查是否需要记录fc1的输出（即ReLU的输入）
        x = self.fc1(x)
        if record_input:
            self.hidden_layer_input = x
        x = self.relu(x)
        x = self.fc2(x)
        return x


model = AdvancedNet()
# 生成随机输入
input_data = torch.randn(1, 10)
# 正常前向传递并记录fc1的输出
output = model(input_data, record_input=True)
# 输出记录的隐藏层输入
print("Recorded hidden layer input:", model.hidden_layer_input)


# 假设我们已经有了想要注入的隐藏层输入
inject_input = torch.randn(1, 5)  # 确保这个输入的维度与模型中该层的期望输入维度相匹配
# 使用外部输入得到输出
output_with_injected_input = model(None, inject_input=inject_input)
print("Output with injected hidden layer input:", output_with_injected_input)
